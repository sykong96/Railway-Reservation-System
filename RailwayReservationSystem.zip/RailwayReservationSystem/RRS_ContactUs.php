<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
	<title>About Us</title>
	<link rel="stylesheet" href="RRS_Style.css">
  </head>
  <body>
           <ul>
		      <li><a href="RRS_Home.php">Home</a></li>
			  <li><a href="RRS_AboutUs.php">About Us</a></li>
			  <li><a href="#">Book Ticket</a></li>
			  <li><a href="RRS_custviewAnnouncement.php">Announcement</a></li>
			  <li class="active"><a href="RRS_ContactUs.php">Contact Us</a></li>
			  <li><a href="login.php">Login</a></li>
			  <li><a href="register.php">Register</a></li>
		   <ul>
  <div class="team-section">
  <span class="border"></span>
    <h1>Location</h1>
	<span class="border"></span>
  <div class="ps">
    <a href="RRS_Home.php"><img src="about_ktm.jpg" width="800" height="400" alt=""></a>
	<br></br>
    <p>Legal and Secretarial Services Unit,
       2nd Floor, KTMB Corporate Headquarters,
       Jalan Sultan Hishamuddin,
       50621 Wilayah Persekutuan,
       Kuala Lumpur.</p>
	<br></br>
	<span class="border"></span>
	<h1>Call Center</h1>
	<span class="border"></span>
	<p>+603 - 2267 1200</p>
    <br></br>
	<span class="border"></span>
	<h1> Operation 24 Hours</h1>
   <span class="border"></span>
   <h1>Email : callcenter@rrs.com.my</h1>
   <span class="border"></span> 	
  </div>
  
  </div>
  
  </body>
 </html>