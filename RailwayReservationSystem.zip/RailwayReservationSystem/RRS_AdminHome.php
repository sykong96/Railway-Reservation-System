<!DOCTYPE html>
<html>
<head>
     <title>Railway Reservation System - RRS</title>
	 <link href='RRS_Style.css' rel='stylesheet'>
</head>
<body>
     <header>
	    <div class="main">
		   <ul>
		      <li class="active"><a href="RRS_AdminHome.php">Home</a></li>
			  <li><a href="RRS_viewSchedule.php">Manage Train Schedule</a></li>
			  <li><a href="RRS_viewAnnouncement.php">Manage Announcement</a></li>
			  <li><a href="RRS_adminviewCustProfile.php">Manage Profile</a></li>
			  <li><a href="staff_login.php">Logout</a></li>
		   <ul>
		</div>
		<div class="title">
		   <h1>Eistern Company Creation</h1>
		</div>
		
		<div class="button">
		   <a href="https://www.youtube.com/watch?v=gItS2GYn39Q" class="btn">Check It Out About RRS</a>
		   <a href="http://www.ktmb.com.my/ETS.html" class="btn">LEARN MORE</a>
		   		
	 </header>
</body>
</html>